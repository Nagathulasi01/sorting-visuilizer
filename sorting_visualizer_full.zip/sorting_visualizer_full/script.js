let array = [];
let sorting = false;
let speed = 200;
let comparisons = 0;
let swaps = 0;
let startTime;

// Algorithm information
const algoInfo = {
  bubble: {
    name: "Bubble Sort",
    description: "Bubble Sort is a simple sorting algorithm that repeatedly steps through the list, compares adjacent elements and swaps them if they are in the wrong order. The pass through the list is repeated until the list is sorted.",
    complexity: {
      time: "O(n²)",
      space: "O(1)"
    }
  },
  selection: {
    name: "Selection Sort",
    description: "Selection Sort divides the input list into two parts: a sorted sublist and an unsorted sublist. It repeatedly finds the minimum element from the unsorted part and moves it to the end of the sorted part.",
    complexity: {
      time: "O(n²)",
      space: "O(1)"
    }
  },
  merge: {
    name: "Merge Sort",
    description: "Merge Sort is a divide-and-conquer algorithm that divides the input array into two halves, recursively sorts each half, and then merges the two sorted halves.",
    complexity: {
      time: "O(n log n)",
      space: "O(n)"
    }
  },
  quick: {
    name: "Quick Sort",
    description: "Quick Sort is a divide-and-conquer algorithm that selects a 'pivot' element and partitions the array around the pivot, placing smaller elements before it and larger elements after it, then recursively sorts the subarrays.",
    complexity: {
      time: "O(n log n) average, O(n²) worst",
      space: "O(log n)"
    }
  },
  insertion: {
    name: "Insertion Sort",
    description: "Insertion Sort builds the final sorted array one item at a time by repeatedly taking the next item and inserting it into the correct position in the already-sorted portion.",
    complexity: {
      time: "O(n²)",
      space: "O(1)"
    }
  }
};

// Initialize the app
document.addEventListener('DOMContentLoaded', () => {
  generateRandomArray();
  updateAlgorithmInfo();
  
  // Event listeners for controls
  document.getElementById('arraySize').addEventListener('input', (e) => {
    if (!sorting) {
      generateRandomArray(parseInt(e.target.value));
    }
  });
  
  document.getElementById('speed').addEventListener('input', (e) => {
    speed = 510 - e.target.value; // Invert the value (10-500 becomes 500-10)
  });
  
  document.getElementById('algorithm').addEventListener('change', updateAlgorithmInfo);
});

function updateAlgorithmInfo() {
  const algo = document.getElementById('algorithm').value;
  const info = algoInfo[algo];
  
  const infoContent = document.getElementById('infoContent');
  infoContent.innerHTML = `
    <p><strong>${info.name}</strong></p>
    <p>${info.description}</p>
    <p><strong>Time Complexity:</strong> ${info.complexity.time}</p>
    <p><strong>Space Complexity:</strong> ${info.complexity.space}</p>
  `;
}

function generateRandomArray(size = document.getElementById('arraySize').value) {
  if (sorting) return;
  
  array = [];
  for (let i = 0; i < size; i++) {
    array.push(Math.floor(Math.random() * 100) + 1); // Ensure minimum height of 1
  }
  renderArray();
  resetStats();
}

function setCustomArray() {
  if (sorting) return;
  
  const input = document.getElementById('userInput').value;
  const values = input.split(',').map(Number).filter(n => !isNaN(n));
  
  if (values.length === 0) {
    alert("Please enter valid numbers separated by commas.");
    return;
  }
  
  array = values;
  document.getElementById('arraySize').value = array.length;
  renderArray();
  resetStats();
}

function renderArray(highlight = [], swap = []) {
  const container = document.getElementById('arrayContainer');
  container.innerHTML = '';
  
  const maxValue = Math.max(...array, 1); // Avoid division by zero
  
  for (let i = 0; i < array.length; i++) {
    const bar = document.createElement('div');
    bar.classList.add('bar');
    bar.style.height = `${(array[i] / maxValue) * 100}%`;
    bar.textContent = array[i];
    
    if (highlight.includes(i)) {
      bar.style.backgroundColor = '#f72585'; // Highlight color
    } else if (swap.includes(i)) {
      bar.style.backgroundColor = '#4cc9f0'; // Swap color
    } else {
      bar.style.backgroundColor = '#4895ef'; // Default color
    }
    
    container.appendChild(bar);
  }
}

function updateStats() {
  document.getElementById('comparisons').textContent = comparisons;
  document.getElementById('swaps').textContent = swaps;
  document.getElementById('time').textContent = sorting ? 
    (new Date() - startTime) : 0;
}

function resetStats() {
  comparisons = 0;
  swaps = 0;
  updateStats();
}

async function startSort() {
  if (sorting) return;
  
  sorting = true;
  comparisons = 0;
  swaps = 0;
  startTime = new Date();
  
  const algo = document.getElementById('algorithm').value;
  
  try {
    switch (algo) {
      case 'bubble':
        await bubbleSort();
        break;
      case 'selection':
        await selectionSort();
        break;
      case 'merge':
        await mergeSort(0, array.length - 1);
        break;
      case 'quick':
        await quickSort(0, array.length - 1);
        break;
      case 'insertion':
        await insertionSort();
        break;
    }
    
    // Final render with all bars green to indicate completion
    const container = document.getElementById('arrayContainer');
    const bars = container.querySelectorAll('.bar');
    bars.forEach(bar => {
      bar.style.backgroundColor = '#4ad66d'; // Success color
    });
    
  } catch (error) {
    console.error("Sorting error:", error);
  } finally {
    sorting = false;
  }
}

// Sorting algorithms with stats tracking
async function bubbleSort() {
  for (let i = 0; i < array.length - 1; i++) {
    for (let j = 0; j < array.length - i - 1; j++) {
      comparisons++;
      updateStats();
      
      renderArray([j, j + 1]);
      await sleep(speed);
      
      if (array[j] > array[j + 1]) {
        [array[j], array[j + 1]] = [array[j + 1], array[j]];
        swaps++;
        updateStats();
        
        renderArray([], [j, j + 1]);
        await sleep(speed);
      }
    }
  }
  renderArray();
}

async function selectionSort() {
  for (let i = 0; i < array.length; i++) {
    let minIndex = i;
    for (let j = i + 1; j < array.length; j++) {
      comparisons++;
      updateStats();
      
      renderArray([j, minIndex]);
      await sleep(speed);
      
      if (array[j] < array[minIndex]) {
        minIndex = j;
      }
    }
    
    if (minIndex !== i) {
      [array[i], array[minIndex]] = [array[minIndex], array[i]];
      swaps++;
      updateStats();
      
      renderArray([], [i, minIndex]);
      await sleep(speed);
    }
  }
  renderArray();
}

async function mergeSort(l, r) {
  if (l >= r) return;
  const m = Math.floor((l + r) / 2);
  await mergeSort(l, m);
  await mergeSort(m + 1, r);
  await merge(l, m, r);
}

async function merge(l, m, r) {
  const left = array.slice(l, m + 1);
  const right = array.slice(m + 1, r + 1);
  let i = 0, j = 0, k = l;

  while (i < left.length && j < right.length) {
    comparisons++;
    updateStats();
    
    renderArray([k, l + i, m + 1 + j]);
    await sleep(speed);
    
    if (left[i] <= right[j]) {
      array[k] = left[i++];
    } else {
      array[k] = right[j++];
    }
    
    renderArray([], [k]);
    await sleep(speed);
    k++;
  }

  while (i < left.length) {
    array[k++] = left[i++];
    renderArray([], [k - 1]);
    await sleep(speed);
  }

  while (j < right.length) {
    array[k++] = right[j++];
    renderArray([], [k - 1]);
    await sleep(speed);
  }
}

async function quickSort(low, high) {
  if (low < high) {
    const pi = await partition(low, high);
    await quickSort(low, pi - 1);
    await quickSort(pi + 1, high);
  }
}

async function partition(low, high) {
  const pivot = array[high];
  let i = low - 1;

  for (let j = low; j < high; j++) {
    comparisons++;
    updateStats();
    
    renderArray([j, high]);
    await sleep(speed);
    
    if (array[j] < pivot) {
      i++;
      [array[i], array[j]] = [array[j], array[i]];
      swaps++;
      updateStats();
      
      renderArray([], [i, j]);
      await sleep(speed);
    }
  }

  [array[i + 1], array[high]] = [array[high], array[i + 1]];
  swaps++;
  updateStats();
  
  renderArray([], [i + 1, high]);
  await sleep(speed);
  return i + 1;
}

async function insertionSort() {
  for (let i = 1; i < array.length; i++) {
    let key = array[i];
    let j = i - 1;
    
    while (j >= 0 && array[j] > key) {
      comparisons++;
      updateStats();
      
      renderArray([j, i]);
      await sleep(speed);
      
      array[j + 1] = array[j];
      swaps++;
      updateStats();
      
      renderArray([], [j + 1]);
      await sleep(speed);
      j--;
    }
    
    array[j + 1] = key;
    renderArray([], [j + 1]);
    await sleep(speed);
  }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}